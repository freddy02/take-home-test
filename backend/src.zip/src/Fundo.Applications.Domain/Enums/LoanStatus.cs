﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fundo.Applications.Domain.Enums
{
    public enum LoanStatus
    {
        Active = 1,
        Inactive = 2,
        Pending = 3,
    }
}
