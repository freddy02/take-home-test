﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fundo.Applications.Application.DTO
{
    public class PaymentDTO
    {
        public decimal PaidAmount { get; set; }
    }
}
